import os
from graphviz import Source

from parsing.parser import split_into_stages
from parsing.extractor import extract_raw_blocks
from parsing.lineage_order import order_by_lineage

from llm.llm_normalizer import normalize_stage
from llm.llm_dot_compiler import generate_dot

from rendering.dot_sanitizer import clean_and_validate_dot


INPUT_FOLDER = "data/input"
OUTPUT_FOLDER = "data/output"


def process_file(file_path: str, file_name: str):

    with open(file_path, "r", encoding="utf-8") as f:
        pseudo = f.read()

    print(f"\nProcessing: {file_name}")

    raw_stages = split_into_stages(pseudo)

    structured_stages = []

    for stage in raw_stages:

        raw = extract_raw_blocks(stage["block"])

        normalized = normalize_stage(stage["stage_id"], raw)

        print("\n===========normalized stage========")
        print(normalized)
        print("===========================")

        normalized["inputs"] = raw.get("inputs", [])
        normalized["outputs"] = raw.get("outputs", [])

        structured_stages.append(normalized)

    # Order stages based on dataset flow
    structured_stages = order_by_lineage(structured_stages)

    workflow_name = file_name.replace(".txt", "")

    dot_code = generate_dot(workflow_name, structured_stages)

    dot_code = clean_and_validate_dot(dot_code)

    os.makedirs(OUTPUT_FOLDER, exist_ok=True)

    output_path = os.path.join(OUTPUT_FOLDER, workflow_name)

    src = Source(dot_code)
    src.render(output_path, format="pdf", cleanup=True)

    print(f"Rendered: {output_path}.pdf")


def run_agent():

    if not os.path.exists(INPUT_FOLDER):
        raise FileNotFoundError("data/input folder not found")

    files = [f for f in os.listdir(INPUT_FOLDER) if f.endswith(".txt")]

    if not files:
        print("No input files found.")
        return

    for file in files:
        process_file(os.path.join(INPUT_FOLDER, file), file)


if __name__ == "__main__":
    run_agent()

# import os
# import json
 
# from parsing.parser import split_into_stages
# from parsing.extractor import extract_raw_blocks
# from llm.llm_normalizer import normalize_stage
# from rendering.hybrid_builder import build_simple_hybrid
 
 
# INPUT_FOLDER = "data/input"
# OUTPUT_FOLDER = "data/output"
 
 
# # --------------------------------------------------------
# # Process Single File
# # --------------------------------------------------------
 
# def process_file(file_path: str, file_name: str):
 
#     with open(file_path, "r", encoding="utf-8") as f:
#         pseudo = f.read()
 
#     print(f"\nProcessing: {file_name}")
 
#     stages = split_into_stages(pseudo)
#     final_stages = []
 
#     for stage in stages:
 
#         # Step 1: Extract raw SQL + transform blocks
#         raw = extract_raw_blocks(stage["block"])
 
#         # Step 2: Normalize stage
#         normalized = normalize_stage(stage["stage_id"], raw)
 
#         # Step 3: Preserve dataset lineage
#         normalized["inputs"] = raw.get("inputs", [])
#         normalized["outputs"] = raw.get("outputs", [])
 
#         print("\n=========== Normalized Stage ===========")
#         print(json.dumps(normalized, indent=2))
#         print("========================================")
 
#         final_stages.append(normalized)
 
#     # Optional: sort for stable output
#     final_stages = sorted(final_stages, key=lambda x: x["stage_id"])
 
#     # Step 4: Build Simple Hybrid Graph
#     base = file_name.replace(".txt", "")
#     output_path = os.path.join(OUTPUT_FOLDER, f"{base}_hybrid")
 
#     build_simple_hybrid(final_stages, output_path)
 
#     print(f"\nHybrid lineage rendered at: {output_path}.pdf\n")
 
 
# # --------------------------------------------------------
# # Run Agent
# # --------------------------------------------------------
 
# def run_agent():
 
#     os.makedirs(OUTPUT_FOLDER, exist_ok=True)
 
#     if not os.path.isdir(INPUT_FOLDER):
#         raise FileNotFoundError(f"Input folder not found: {INPUT_FOLDER}")
 
#     files = [f for f in os.listdir(INPUT_FOLDER) if f.endswith(".txt")]
 
#     if not files:
#         print(f"No .txt files found in {INPUT_FOLDER}")
#         return
 
#     for file in files:
#         file_path = os.path.join(INPUT_FOLDER, file)
#         try:
#             process_file(file_path, file)
#         except Exception as e:
#             print(f"[ERROR] Failed to process {file}: {e}")
 
#     print("Done.")
 
 
# if __name__ == "__main__":
#     run_agent()
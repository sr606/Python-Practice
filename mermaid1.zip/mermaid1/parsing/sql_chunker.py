import re


def chunk_sql(sql_text, max_chars=4000):

    if len(sql_text) <= max_chars:
        return [sql_text]

    # Split by LEFT JOIN boundaries
    chunks = re.split(r"\bLEFT\s+JOIN\b", sql_text, flags=re.IGNORECASE)

    rebuilt_chunks = []

    current = ""

    for part in chunks:
        candidate = current + " LEFT JOIN " + part if current else part

        if len(candidate) > max_chars:
            rebuilt_chunks.append(current.strip())
            current = part
        else:
            current = candidate

    if current:
        rebuilt_chunks.append(current.strip())

    return rebuilt_chunks

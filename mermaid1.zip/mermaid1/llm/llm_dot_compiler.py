import json
from openai import AzureOpenAI
from config.settings import (
    AZURE_OPENAI_API_KEY,
    AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_ENDPOINT,
    AZURE_OPENAI_DEPLOYMENT
)

client = AzureOpenAI(
    api_key=AZURE_OPENAI_API_KEY,
    api_version=AZURE_OPENAI_API_VERSION,
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
)


PROMPT = """
You are a professional Graphviz workflow compiler.

Generate COMPLETE valid DOT code.

STRICT RULES:

- rankdir=LR
- bgcolor="white"
- node [shape=plain, fontname="Helvetica"]
- Use subgraph cluster_workflow
- Do NOT use markdown
- Do NOT use ```
- Do NOT rename stage_id
- Do NOT remove any joins or transformations from input

IMPORTANT:

The input contains FULL joins and FULL transformation logic.

You must:

1. Preserve ALL items
2. Convert each join into a SHORT semantic bullet
3. Convert each transformation into a SHORT semantic bullet
4. DO NOT drop any item
5. DO NOT limit number of bullets
6. Each bullet max 12 words

Example:

Raw:
LEFT JOIN cdm_owner.vehicle_dim v ON vor.registration_number = v.registration_no

Bullet:
• Join vehicle_dim using registration number

Raw:
SUPP_SK ← CASE WHEN CAPTURED_GARAGE_NAME IS NULL ...

Bullet:
• Derive SUPP_SK using supplier classification logic

NODE TEMPLATE (STRICT):

STAGE_ID [
    label=<
        <table border="0" cellborder="1" cellspacing="0" cellpadding="6" width="520">
            <tr>
                <td bgcolor="#E3F2FD">
                    <b>STAGE_ID</b>
                </td>
            </tr>

            <tr>
                <td align="left">
                    <b>Primary Tables</b><br/>
                    BULLETS_PRIMARY<br/><br/>

                    <b>Joins</b><br/>
                    BULLETS_JOINS<br/><br/>

                    <b>Transformations</b><br/>
                    BULLETS_TRANSFORM
                </td>
            </tr>
        </table>
    >
];

Create edges using inputs → outputs.

Output must start with:

digraph WORKFLOW_NAME {
"""


def generate_dot(workflow_name, stages):

    minimal_stages = []
    for s in stages:
        minimal_stages.append({
        "stage_id": s["stage_id"],
        "inputs": s.get("inputs", []),
        "outputs": s.get("outputs", []),
        "primary_tables": s.get("primary_tables", []),
        "joins": s.get("joins", [])[:5],
        "filters": s.get("filters", []),
        "transformations": s.get("transformations", [])[:6]
    })
    payload = json.dumps({
    "workflow_name": workflow_name,
    "stages": minimal_stages
    }, ensure_ascii=False)

    response = client.chat.completions.create(
        model=AZURE_OPENAI_DEPLOYMENT,
        temperature=0,
        messages=[
            {"role": "system", "content": "You generate strictly valid Graphviz DOT."},
            {"role": "user", "content": PROMPT + "\n\nWorkflow JSON:\n" + payload}
        ]
        # ,
        # stop=["```"]
    )

    print("\n====FULL RESPONSE OBJECT====")
    print(response)
    print("==========================\n")


    print("\n====RAW MODEL CONTENT====")
    print(response.choices[0].message.content)
    print("==========================\n")

    return response.choices[0].message.content.strip()
import json

import re

from openai import AzureOpenAI

from config.settings import (

    AZURE_OPENAI_API_KEY,

    AZURE_OPENAI_API_VERSION,

    AZURE_OPENAI_ENDPOINT,

    AZURE_OPENAI_DEPLOYMENT

)
 
# ------------------------------------------------------------------

# Azure OpenAI Client

# ------------------------------------------------------------------
 
client = AzureOpenAI(

    api_key=AZURE_OPENAI_API_KEY,

    api_version=AZURE_OPENAI_API_VERSION,

    azure_endpoint=AZURE_OPENAI_ENDPOINT,

)
 
# ------------------------------------------------------------------

# SQL Chunking (Prevents token overflow)

# ------------------------------------------------------------------
 
def chunk_sql(sql_text, max_chars=4000):

    if not sql_text:

        return []
 
    if len(sql_text) <= max_chars:

        return [sql_text]
 
    # Split logically by JOIN boundaries

    chunks = re.split(r"\b(LEFT|RIGHT|INNER|FULL)\s+JOIN\b", sql_text, flags=re.IGNORECASE)
 
    rebuilt = []

    current = ""
 
    for part in chunks:

        candidate = current + " " + part if current else part
 
        if len(candidate) > max_chars:

            if current:

                rebuilt.append(current.strip())

            current = part

        else:

            current = candidate
 
    if current:

        rebuilt.append(current.strip())
 
    return rebuilt
 
 
# ------------------------------------------------------------------

# Deterministic Base Table Extraction (NO LLM)

# ------------------------------------------------------------------
 
def extract_base_tables(sql_text):

    if not sql_text:

        return []
 
    tables = re.findall(r"\bFROM\s+([a-zA-Z0-9_\.]+)", sql_text, re.IGNORECASE)

    return list(set(tables))
 
 
# ------------------------------------------------------------------

# Deterministic Transformation Extraction (For Transformer stages)

# ------------------------------------------------------------------
 
def extract_transformations(transform_text):

    results = []
 
    for line in transform_text.split("\n"):

        line = line.strip()

        if "=" in line and not line.startswith("--"):

            parts = line.split("=", 1)

            results.append({

                "target": parts[0].strip(),

                "logic": parts[1].strip()

            })
 
    return results
 
 
# ------------------------------------------------------------------

# LLM Prompt (NO DATA LOSS)

# ------------------------------------------------------------------
 
PROMPT = """

Extract structured lineage from SQL.
 
Return STRICT JSON only:
 
{

  "stage_id": "",

  "primary_tables": [],

  "joins": [

    {

      "join_type": "",

      "table": "",

      "condition": ""

    }

  ],

  "filters": [],

  "transformations": [

    {

      "target": "",

      "logic": ""

    }

  ]

}
 
IMPORTANT:
 
- Extract ALL joins (including nested)

- Keep FULL join conditions

- Do NOT truncate logic

- Do NOT remove items

- Do NOT summarize

- Do NOT hallucinate

- If something does not exist, return empty list

"""
 
 
# ------------------------------------------------------------------

# Main Normalizer Function

# ------------------------------------------------------------------

def extract_joins(sql_text):
    if not sql_text:
        return []
 
    join_pattern = re.findall(
        r"""
        \b
        (LEFT|RIGHT|INNER|FULL)?      # Join type
        \s*
        (OUTER\s+)?                   # Optional OUTER
        JOIN
        \s+
        (
            \([^\)]*?\)               # Subquery join
            |
            [a-zA-Z0-9_\.]+           # Regular table
        )
        \s+
        .*?
        \bON\b
        \s+
        (.*?)
        (?=
            \bLEFT\b|
            \bRIGHT\b|
            \bINNER\b|
            \bFULL\b|
            \bWHERE\b|
            \bGROUP\b|
            \bORDER\b|
            $
        )
        """,
        sql_text,
        re.IGNORECASE | re.DOTALL | re.VERBOSE
    )
 
    joins = []
 
    for jt, outer, table, condition in join_pattern:
        join_type = (jt.upper() if jt else "JOIN") + " JOIN"
        joins.append({
            "join_type": join_type,
            "table": table.strip(),
            "condition": condition.strip()
        })
 
    return joins
 
def normalize_stage(stage_id, raw):
 
    sql_text = raw.get("sql", "")

    transform_text = raw.get("transform", "")
 
    # -----------------------------------------

    # Case 1: Transformer stage (No SQL)

    # -----------------------------------------
 
    if not sql_text and transform_text:

        return {

            "stage_id": stage_id,

            "primary_tables": [],

            "joins": [],

            "filters": [],

            "transformations": extract_transformations(transform_text)

        }
 
    # -----------------------------------------

    # Case 2: SQL Stage

    # -----------------------------------------
 
    combined = {

        "stage_id": stage_id,

        "primary_tables": [],

        "joins": extract_joins(sql_text),

        "filters": [],

        "transformations": []

    }
 
    # Deterministic base table extraction

    base_tables = extract_base_tables(sql_text)

    combined["primary_tables"].extend(base_tables)
 
    # Chunk SQL to avoid token overflow

    sql_chunks = chunk_sql(sql_text)
 
    for chunk in sql_chunks:
 
        response = client.chat.completions.create(

            model=AZURE_OPENAI_DEPLOYMENT,

            temperature=0,

            messages=[

                {"role": "system", "content": "You extract SQL lineage strictly."},

                {

                    "role": "user",

                    "content": PROMPT +

                    f"\nStage ID: {stage_id}\n\nSQL:\n{chunk}"

                }

            ]

        )
 
        content = response.choices[0].message.content.strip()
 
        try:

            parsed = json.loads(content)
 
            combined["joins"].extend(parsed.get("joins", []))

            combined["filters"].extend(parsed.get("filters", []))

            combined["transformations"].extend(parsed.get("transformations", []))
 
        except Exception:

            continue
 
    # Deduplicate primary tables

    combined["primary_tables"] = list(set(combined["primary_tables"]))
 
    return combined
 
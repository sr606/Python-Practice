from graphviz import Digraph


def sanitize_id(name: str) -> str:
    return name.replace(".", "_").replace("-", "_").replace(" ", "_")


def build_simple_hybrid(stages, output_path):

    dot = Digraph("HYBRID_WORKFLOW", format="pdf")
    dot.attr(rankdir="LR", bgcolor="white")
    dot.attr("node", fontname="Helvetica")

    # --------------------------------------------------
    # Collect all source tables
    # --------------------------------------------------

    all_tables = set()
    for stage in stages:
        for table in stage.get("primary_tables", []):
            all_tables.add(table)

    # --------------------------------------------------
    # SOURCE CLUSTER
    # --------------------------------------------------

    with dot.subgraph(name="cluster_sources") as c:
        c.attr(label="Source Tables", style="rounded", color="#90CAF9")

        for table in sorted(all_tables):
            c.node(
                sanitize_id(table),
                table,
                shape="box",
                style="filled",
                fillcolor="#E3F2FD"
            )

    # --------------------------------------------------
    # STAGE CLUSTER
    # --------------------------------------------------

    with dot.subgraph(name="cluster_stages") as c:
        c.attr(label="ETL Stages", style="rounded", color="#FFB74D")

        for stage in stages:
            c.node(
                sanitize_id(stage["stage_id"]),
                stage["stage_id"],
                shape="box",
                style="filled",
                fillcolor="#FFE0B2"
            )

    # --------------------------------------------------
    # TABLE → STAGE EDGES
    # --------------------------------------------------

    for stage in stages:
        stage_id = sanitize_id(stage["stage_id"])

        for table in stage.get("primary_tables", []):
            dot.edge(
                sanitize_id(table),
                stage_id
            )

    # --------------------------------------------------
    # STAGE → STAGE EDGES
    # (Using dataset inputs/outputs)
    # --------------------------------------------------

    dataset_to_stage = {}

    for stage in stages:
        for output in stage.get("outputs", []):
            dataset_to_stage[output] = stage["stage_id"]

    for stage in stages:
        for input_ds in stage.get("inputs", []):
            if input_ds in dataset_to_stage:
                dot.edge(
                    sanitize_id(dataset_to_stage[input_ds]),
                    sanitize_id(stage["stage_id"])
                )

    dot.render(output_path, cleanup=True)


    from rendering.hybrid_builder import build_simple_hybrid

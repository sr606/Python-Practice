import re
import html


def clean_and_validate_dot(dot_text: str):

    if not dot_text:
        raise ValueError("LLM returned empty response.")

    # 1️⃣ Remove markdown fences like ```dot ``` or ```
    dot_text = re.sub(r"```[\w]*", "", dot_text)
    dot_text = re.sub(r"```", "", dot_text)

    # 2️⃣ Remove triple single quotes if present
    dot_text = dot_text.replace("'''", "")

    # 3️⃣ Remove leading/trailing whitespace
    dot_text = dot_text.strip()

    # 4️⃣ Unescape HTML entities
    dot_text = html.unescape(dot_text)

    # 5️⃣ Extract only digraph block
    match = re.search(r"(digraph\s+[^{]+\{.*\})", dot_text, re.DOTALL)

    if not match:
        raise ValueError(
            "No valid digraph block found.\n\nRAW OUTPUT:\n"
            + dot_text[:800]
        )

    dot_block = match.group(1).strip()

    # 6️⃣ Validate braces
    if dot_block.count("{") != dot_block.count("}"):
        raise ValueError("Unbalanced braces in DOT.")

    return dot_block
import time
import random

def retry_llm_call(func, max_retries=3, base_delay=1.5):

    last_error = None

    for attempt in range(max_retries):
        try:
            return func()
        except Exception as e:
            last_error = e
            if attempt == max_retries - 1:
                raise last_error

            sleep_time = base_delay * (2 ** attempt) + random.uniform(0, 0.5)
            print(f"[Retry {attempt+1}] LLM failed: {e}. Retrying in {sleep_time:.2f}s")
            time.sleep(sleep_time)
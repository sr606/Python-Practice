import re
 
def sanitize_graph_name(name: str) -> str:
    name = name.replace(".txt", "")
    name = re.sub(r"[^a-zA-Z0-9_]", "_", name)
 
    if name and name[0].isdigit():
        name = "G_" + name
 
    return name
 
 
def sanitize_node(name: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_]", "_", name)
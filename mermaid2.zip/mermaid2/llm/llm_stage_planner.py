import json
import re
from openai import AzureOpenAI
from config.settings import *

from utils.retry import retry_llm_call

client = AzureOpenAI(
    api_key=AZURE_OPENAI_API_KEY,
    api_version=AZURE_OPENAI_API_VERSION,
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
)

STAGE_PLANNER_PROMPT = """
Classify the stage into architecture layer.

Return STRICT JSON:

{
  "stage_id": "",
  "layer": "",
  "color": "",
  "node_shape": "",
  "is_decision": false
}

Rules:
- Source → cylinder, color #CFE2F3
- Integration → box, color #FFF2CC
- Business → box, color #F8CBAD
- Target → cylinder, color #E2D5F9
- If multiple outputs → is_decision = true
No explanation.
"""

def safe_json_parse(text):
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        return json.loads(match.group(0))
    raise ValueError("Invalid JSON")

def classify_stage_architecture(stage, semantic):

    payload = {
        "stage_id": stage["stage_id"],
        "inputs": stage.get("inputs", []),
        "outputs": stage.get("outputs", []),
        "semantic": semantic
    }

    def call():
        response = client.chat.completions.create(
            model=AZURE_OPENAI_DEPLOYMENT,
            temperature=0,
            max_tokens=400,
            messages=[
                {"role": "system", "content": "Return JSON only."},
                {"role": "user", "content": STAGE_PLANNER_PROMPT + "\n\n" + json.dumps(payload)}
            ]
        )
        return safe_json_parse(response.choices[0].message.content)

    return retry_llm_call(call)
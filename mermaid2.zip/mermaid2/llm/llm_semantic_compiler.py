import json
import re
from openai import AzureOpenAI
from config.settings import *

from utils.retry import retry_llm_call

client = AzureOpenAI(
    api_key=AZURE_OPENAI_API_KEY,
    api_version=AZURE_OPENAI_API_VERSION,
    azure_endpoint=AZURE_OPENAI_ENDPOINT,
)

PROMPT = """
Summarize SQL and transformation logic into semantic bullets.

Return STRICT JSON:
{
  "stage_id": "",
  "summary": ""
}
No explanation.
"""

def safe_json_parse(text):
    match = re.search(r"\{.*\}", text, re.DOTALL)
    if match:
        return json.loads(match.group(0))
    raise ValueError("Invalid JSON")

def generate_semantic_nodes(stages):

    semantic_nodes = []

    for s in stages:

        payload = {
            "stage_id": s["stage_id"],
            "sql": s.get("sql", ""),
            "transform": s.get("transform", "")
        }

        def call():
            response = client.chat.completions.create(
                model=AZURE_OPENAI_DEPLOYMENT,
                temperature=0,
                max_tokens=600,
                messages=[
                    {"role": "system", "content": "Return JSON only."},
                    {"role": "user", "content": PROMPT + "\n\n" + json.dumps(payload)}
                ]
            )
            return safe_json_parse(response.choices[0].message.content)

        semantic_nodes.append(retry_llm_call(call))

    return semantic_nodes
import os
from graphviz import Source
 
# ---------------------------
# Parsing
# ---------------------------
from parsing.parser import split_into_stages
from parsing.extractor import extract_raw_blocks
from parsing.lineage_order import order_by_lineage
 
# ---------------------------
# LLM Layers
# ---------------------------
from llm.llm_semantic_compiler import generate_semantic_nodes
from llm.llm_stage_planner import classify_stage_architecture
 
# ---------------------------
# Architecture
# ---------------------------
from architecture.architecture_merger import merge_stage_plans
 
# ---------------------------
# Rendering
# ---------------------------
from rendering.enterprise_dot_renderer import render_architecture_dot
from rendering.dot_optimizer import optimize_dot_layout
from rendering.dot_sanitizer import clean_and_validate_dot
 
# ---------------------------
# Utilities
# ---------------------------
from utils.name_sanitizer import sanitize_graph_name
 
 
# ==============================================
# CONFIGURATION
# ==============================================
 
INPUT_FOLDER = "data/input"
OUTPUT_FOLDER = "data/output"
 
# Modes: "cio" | "technical" | "hybrid"
RENDER_MODE = "hybrid"
 
 
# ==============================================
# PROCESS SINGLE FILE
# ==============================================
 
def process_file(file_path: str, file_name: str):
 
    print(f"\nProcessing: {file_name}")
 
    with open(file_path, "r", encoding="utf-8") as f:
        pseudo = f.read()
 
    # ---------------------------
    # 1. Parse Stages
    # ---------------------------
    raw_stages = split_into_stages(pseudo)
 
    structured_stages = []
 
    for stage in raw_stages:
 
        raw = extract_raw_blocks(stage["block"])
 
        structured_stages.append({
            "stage_id": stage["stage_id"],
            "sql": raw.get("sql", ""),
            "transform": raw.get("transform", ""),
            "inputs": raw.get("inputs", []),
            "outputs": raw.get("outputs", [])
        })
 
    # ---------------------------
    # 2. Order by Lineage
    # ---------------------------
    structured_stages = order_by_lineage(structured_stages)
 
    # ---------------------------
    # 3. Sanitize Graph Name
    # ---------------------------
    workflow_name = sanitize_graph_name(file_name)
 
    # ---------------------------
    # 4. Semantic Extraction (LLM)
    # ---------------------------
    semantic_nodes = generate_semantic_nodes(structured_stages)
 
    # ---------------------------
    # 5. Chunked Stage Classification (LLM per stage)
    # ---------------------------
    stage_plans = []
 
    for stage, semantic in zip(structured_stages, semantic_nodes):
 
        plan = classify_stage_architecture(stage, semantic)
 
        stage_plans.append(plan)
 
    # ---------------------------
    # 6. Deterministic Merge
    # ---------------------------
    architecture_plan = merge_stage_plans(
        workflow_name,
        structured_stages,
        stage_plans
    )
 
    # ---------------------------
    # 7. Render DOT
    # ---------------------------
    dot_code = render_architecture_dot(
        workflow_name,
        architecture_plan,
        structured_stages,
        mode=RENDER_MODE
    )
 
    # ---------------------------
    # 8. Optimize Layout
    # ---------------------------
    dot_code = optimize_dot_layout(dot_code)
 
    # ---------------------------
    # 9. Sanitize / Validate DOT
    # ---------------------------
    dot_code = clean_and_validate_dot(dot_code)
 
    # ---------------------------
    # 10. Render PDF
    # ---------------------------
    os.makedirs(OUTPUT_FOLDER, exist_ok=True)
 
    output_path = os.path.join(OUTPUT_FOLDER, workflow_name)
 
    Source(dot_code).render(output_path, format="pdf", cleanup=True)
 
    print(f"Rendered successfully: {output_path}.pdf")
 
 
# ==============================================
# RUN AGENT
# ==============================================
 
def run_agent():
 
    if not os.path.exists(INPUT_FOLDER):
        raise FileNotFoundError(f"Input folder not found: {INPUT_FOLDER}")
 
    files = [f for f in os.listdir(INPUT_FOLDER) if f.endswith(".txt")]
 
    if not files:
        print("No .txt files found.")
        return
 
    for file in files:
        try:
            process_file(os.path.join(INPUT_FOLDER, file), file)
        except Exception as e:
            print(f"[ERROR] Failed to process {file}: {e}")
 
    print("\nAll workflows processed.")
 
 
if __name__ == "__main__":
    run_agent()
def validate_architecture_plan(plan):

    if not isinstance(plan, dict):
        raise ValueError("Architecture plan must be dictionary.")

    required_keys = ["workflow_type", "layers", "edges"]

    for key in required_keys:
        if key not in plan:
            raise ValueError(f"Missing key in architecture plan: {key}")

    if not isinstance(plan["layers"], list):
        raise ValueError("layers must be list")

    for layer in plan["layers"]:
        if "name" not in layer:
            raise ValueError("Each layer must have name")
        if "nodes" not in layer:
            raise ValueError("Each layer must have nodes")
        if "node_shape" not in layer:
            raise ValueError("Each layer must define node_shape")

    if not isinstance(plan["edges"], list):
        raise ValueError("edges must be list")

    return True
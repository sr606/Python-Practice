import re
import html

def clean_and_validate_dot(dot_text):

    dot_text = html.unescape(dot_text).strip()

    match = re.search(r"(digraph\s+[^{]+\{.*\})", dot_text, re.DOTALL)

    if not match:
        raise ValueError("Invalid DOT structure")

    return match.group(1)
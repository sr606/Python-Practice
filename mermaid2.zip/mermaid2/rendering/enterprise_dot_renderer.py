import re
from utils.name_sanitizer import sanitize_node
 
 
LAYER_PRIORITY = {
    "Source": 1,
    "Integration": 2,
    "Business": 3,
    "Target": 4
}
 
 
def render_architecture_dot(workflow_name, architecture_plan, stages, mode="hybrid"):
 
    layers = sorted(
        architecture_plan["layers"],
        key=lambda x: LAYER_PRIORITY.get(x["name"], 99)
    )
 
    dot = []
 
    dot.append(f'digraph {workflow_name} {{')
    dot.append('rankdir=LR;')
    dot.append('bgcolor="white";')
    dot.append('compound=true;')
    dot.append('newrank=true;')
    dot.append('splines=ortho;')
    dot.append('nodesep=1.0;')
    dot.append('ranksep=1.5;')
    dot.append('fontname="Helvetica";')
    dot.append('node [fontname="Helvetica"];')
    dot.append('edge [fontname="Helvetica"];')
 
    step_number = 1
    anchor_nodes = []
 
    # ==========================================
    # CREATE STRICT SWIMLANES
    # ==========================================
    for layer in layers:
 
        cluster_name = f'cluster_{sanitize_node(layer["name"])}'
        anchor = f'anchor_{sanitize_node(layer["name"])}'
        anchor_nodes.append(anchor)
 
        dot.append(f'subgraph {cluster_name} {{')
        dot.append('style=filled;')
        dot.append(f'label="STEP {step_number} – {layer["name"].upper()}";')
        dot.append(f'fillcolor="{layer["color"]}";')
        dot.append('color="#888888";')
        dot.append('rank=same;')
 
        # Invisible anchor for layout control
        dot.append(
            f'"{anchor}" '
            f'[shape=point, width=0, style=invis];'
        )
 
        for node in layer["nodes"]:
 
            safe_node = sanitize_node(node)
 
            if layer["name"] in ["Source", "Target"]:
                shape = "cylinder"
            else:
                shape = "box"
 
            dot.append(
                f'"{safe_node}" '
                f'[shape={shape}, style=filled, fillcolor="white"];'
            )
 
            # Attach to anchor to align horizontally
            dot.append(
                f'"{anchor}" -> "{safe_node}" '
                f'[style=invis];'
            )
 
        dot.append('}')
        step_number += 1
 
    # ==========================================
    # FORCE LAYER ORDER LEFT → RIGHT
    # ==========================================
    for i in range(len(anchor_nodes) - 1):
        dot.append(
            f'"{anchor_nodes[i]}" '
            f'-> "{anchor_nodes[i+1]}" '
            f'[style=invis, weight=10];'
        )
 
    # ==========================================
    # DECISION NODES
    # ==========================================
    for edge in architecture_plan["edges"]:
        if edge["from"].endswith("_DECISION") or edge["to"].endswith("_DECISION"):
            decision_node = sanitize_node(edge["from"])
            dot.append(
                f'"{decision_node}" '
                f'[shape=diamond, style=filled, fillcolor="white"];'
            )
 
    # ==========================================
    # PROMOTE SOURCE TABLES
    # ==========================================
    if mode in ["technical", "hybrid"]:
 
        for stage in stages:
 
            sql = stage.get("sql", "")
 
            found_tables = re.findall(
                r"\bFROM\s+([a-zA-Z0-9_\.]+)",
                sql,
                re.IGNORECASE
            )
 
            for table in found_tables:
 
                safe_table = sanitize_node(table)
 
                dot.append(
                    f'"{safe_table}" '
                    f'[shape=cylinder, style=filled, fillcolor="white"];'
                )
 
                dot.append(
                    f'"{safe_table}" '
                    f'-> "{sanitize_node(stage["stage_id"])}";'
                )
 
    # ==========================================
    # EDGES
    # ==========================================
    for edge in architecture_plan["edges"]:
        dot.append(
            f'"{sanitize_node(edge["from"])}" '
            f'-> "{sanitize_node(edge["to"])}";'
        )
 
    dot.append('}')
    return "\n".join(dot)
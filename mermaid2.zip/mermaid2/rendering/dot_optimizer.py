def optimize_dot_layout(dot_code):

    lines = dot_code.split("\n")

    lines.insert(1, "nodesep=0.6;")
    lines.insert(2, "ranksep=0.9;")
    lines.insert(3, "splines=true;")

    return "\n".join(lines)
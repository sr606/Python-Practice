import re


def extract_raw_blocks(block):

    sql_match = re.search(r"SQL:(.*?)(StageType:|Output:|$)", block, re.DOTALL)
    sql_block = sql_match.group(1) if sql_match else ""

    transform_match = re.search(r"Transformations:(.*)", block, re.DOTALL)
    transform_block = transform_match.group(1) if transform_match else ""

    input_datasets = re.findall(
        r"Input:\s*←\s*dataset_\d+\s*\(([^)]+)\)", block
    )

    output_datasets = re.findall(
        r"Output:\s*→\s*dataset_\d+\s*\(([^)]+)\)", block
    )

    return {
        "sql": sql_block.strip(),
        "transform": transform_block.strip(),
        "inputs": input_datasets,
        "outputs": output_datasets
    }
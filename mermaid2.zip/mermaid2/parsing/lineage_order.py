def order_by_lineage(stages):

    stage_map = {s["stage_id"]: s for s in stages}
    output_to_stage = {}

    for s in stages:
        for out in s.get("outputs", []):
            output_to_stage[out] = s["stage_id"]

    ordered = []
    visited = set()

    def visit(stage):
        if stage["stage_id"] in visited:
            return

        for inp in stage.get("inputs", []):
            if inp in output_to_stage:
                parent = stage_map[output_to_stage[inp]]
                visit(parent)

        visited.add(stage["stage_id"])
        ordered.append(stage)

    for s in stages:
        visit(s)

    return ordered
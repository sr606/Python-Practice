from utils.name_sanitizer import sanitize_node
 
LAYER_PRIORITY = {
    "Source": 1,
    "Integration": 2,
    "Business": 3,
    "Target": 4
}
 
 
def order_layers(layers_dict):
 
    return sorted(
        layers_dict.values(),
        key=lambda x: LAYER_PRIORITY.get(x["name"], 99)
    )
 
 
def merge_stage_plans(workflow_name, stages, stage_plans):
 
    layers = {}
    edges = []
 
    # ---------------------------
    # Build Layers
    # ---------------------------
    for plan in stage_plans:
 
        layer_name = plan["layer"]
 
        if layer_name not in layers:
            layers[layer_name] = {
                "name": layer_name,
                "color": plan["color"],
                "node_shape": plan["node_shape"],
                "nodes": []
            }
 
        layers[layer_name]["nodes"].append(plan["stage_id"])
 
    # ---------------------------
    # Map outputs to stage
    # ---------------------------
    output_map = {}
    for s in stages:
        for out in s.get("outputs", []):
            output_map[out] = s["stage_id"]
 
    # ---------------------------
    # Structural Decision Injection
    # ---------------------------
    for s in stages:
 
        outputs = s.get("outputs", [])
 
        # Multiple outputs → decision node
        if len(outputs) > 1:
 
            decision_id = s["stage_id"] + "_DECISION"
 
            # Stage → Decision
            edges.append({
                "from": s["stage_id"],
                "to": decision_id
            })
 
            # Decision → Next stages
            for out in outputs:
                if out in output_map:
                    edges.append({
                        "from": decision_id,
                        "to": output_map[out]
                    })
 
        else:
            # Normal flow
            for inp in s.get("inputs", []):
                if inp in output_map:
                    edges.append({
                        "from": output_map[inp],
                        "to": s["stage_id"]
                    })
 
    return {
        "workflow_type": "ETL",
        "layers": order_layers(layers),
        "edges": edges
    }